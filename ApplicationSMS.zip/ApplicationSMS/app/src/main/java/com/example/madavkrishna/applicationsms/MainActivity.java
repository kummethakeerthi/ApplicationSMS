package com.example.madavkrishna.applicationsms;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.app.PendingIntent;
import android.os.Bundle;
import android.telephony.gsm.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;

import android.app.ListActivity;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;


import static android.R.attr.phoneNumber;

public class MainActivity extends Activity  {
    Button btnSendSMS;
    EditText txtPhoneNo;
    EditText txtMessage;
    Button listmessgaes;
    Button sendmessages;
    Button composemessages;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnSendSMS = (Button) findViewById(R.id.btnSendSMS);
        listmessgaes = (Button) findViewById(R.id.smsNumberText);
        sendmessages= (Button) findViewById(R.id.sentText);
//        composemessages=(Button) findViewById(R.id.composeText);
//        composemessages.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                composeMess();
//            }
//        });
        sendmessages.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendMess();
            }
        });

        listmessgaes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                CallMess();
            }
        });

        txtPhoneNo = (EditText) findViewById(R.id.txtPhoneNo);
        txtMessage = (EditText) findViewById(R.id.txtMessage);
        btnSendSMS.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                composeMess();
            }
//                String phoneNo = txtPhoneNo.getText().toString();
//                String message = txtMessage.getText().toString();
//                if (phoneNo.length() > 0 && message.length() > 0)
//                    sendSMS(phoneNo, message);
//                else
//                    Toast.makeText(getBaseContext(),
//                            "Please enter both phone number and message.",
//                            Toast.LENGTH_SHORT).show();
//            }
        });
//
    }

//    private void sendSMS(String phoneNumber, String message) {
//        PendingIntent pi = PendingIntent.getActivity(this, 0,
//                new Intent(this, MainActivity.class), 0);
//        SmsManager sms = SmsManager.getDefault();
//        sms.sendTextMessage(phoneNumber, null, message, pi, null);
//        Toast.makeText(getApplicationContext(),"sent succesfuly",Toast.LENGTH_LONG).show();
//    }
    private void CallMess(){
        Intent i=new Intent(MainActivity.this,ShowInbox.class);
        startActivity(i);

    }
    private void sendMess() {
        Intent i=new Intent(MainActivity.this,SendMessage.class);
        startActivity(i);
    }
    private void composeMess(){
        Intent i=new Intent(MainActivity.this,Composebox.class);
        startActivity(i);
    }


}